   <footer class="main-footer" id="footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Version</b> 0.0.1
      </div>
      <strong>Copyright &copy; 2020 <a href="https://adminlte.io">LSP Polibatam</a>.</strong> All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>