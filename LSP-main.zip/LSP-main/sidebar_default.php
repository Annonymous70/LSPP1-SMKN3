
<ul class="sidebar-menu" data-widget="tree">


<li class="header">Navigasi Utama</li>

<li class="active treeview menu-open">


  <a href="#">

    <i class="fa fa-home"></i>
    <span>Dashboard</span>
    
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>

  </a>


  <ul class="treeview-menu">


    <!-- Data Diri -->
    <li class="">

      <a href="index.php?page=identitas" class="btn-loading">
        <i class="fa fa-user"></i>
        <span>Data Diri</span>
      </a>

    </li>


    <!-- Ajukan Permohonan -->
    <li class="">

      <a href="index.php?page=ajukan_permohonan" class="btn-loading">
        <i class="fa fa-briefcase"></i>
        <span>Ajukan Permohonan Sertifikasi</span>
      </a>

    </li>


    <!-- Menu 3 -->
    <li class="">

      <a href="index.php?page=identitas" class="btn-loading">
        <i class="fa fa-user"></i>
        <span>Menu 3</span>
      </a>

    </li>


    <!-- Menu 4 -->
    <li class="">

      <a href="index.php?page=identitas" class="btn-loading">
        <i class="fa fa-user"></i>
        <span>Menu 4</span>
      </a>

    </li>


    <!-- Menu 5 -->
    <li class="">

      <a href="index.php?page=identitas" class="btn-loading">
        <i class="fa fa-user"></i>
        <span>Menu 5</span>
      </a>

    </li>


    <!-- Menu 6 -->
    <li class="">

      <a href="index.php?page=identitas" class="btn-loading">
        <i class="fa fa-user"></i>
        <span>Menu 6</span>
      </a>

    </li>


  </ul>


</li>

<li class="treeview menu-open" id="akun">


  <a href="#">

    <i class="fa fa-home"></i>
    <span>Pengaturan Akun</span>
    
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>

  </a>


  <ul class="treeview-menu" id="akun">


    <!-- Data Diri -->
    <li class="">

      <a href="index.php?page=ganti_password" class="btn-loading">
        <i class="fa fa-key"></i>
        <span>Ganti Password</span>
      </a>

    </li>



  </ul>




</li>


</ul>