
<ul class="sidebar-menu" data-widget="treeview" data-api="tree" data-accordion="false">


  <li class="header">
    <span><b>Navigasi Utama</b></span>
  </li>


  <li class="active treeview menu-open">

    <a href="#">
      <i class="fa fa-home"></i>
      <span>Dashboard</span>

      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>


      <ul class="treeview-menu">


        <li class="">
          <a href="index.php?page=identitas" class="btn-loading">
            <i class="fa fa-gear"></i>
            <span >Data Diri</span>
          </a>
        </li>


        <li class="">
          <a href="index.php?page=ajukan_permohonan" class="btn-loading">
            <i class="fa fa-user"></i>
            <span>Ajukan Permohonan</span>
          </a>
        </li>


        <li class="">
          <a href="index.php?page=data_permohonan" class="btn-loading">
            <i class="fa fa-user"></i>
            <span>Data Permohonan</span>
          </a>
        </li>

        
        <li class="">
          <a href="index.php?page=ajukan_banding" class="btn-loading">
            <i class="fa fa-user"></i>
            <span>Ajukan Banding</span>
          </a>
        </li>


      </ul>


  </li>


  <li class="active treeview menu-open">


    <a href="#">

      <i class="fa fa-gear"></i>
      <span>Menu Akun</span>

      <span class="pull-right-container">

        <i class="fa fa-angle-left pull-right"></i>
      
      </span>

    </a>


    <ul class="treeview-menu">


      <li class="">
        <a href="index.php?page=pengaturan_akun" class="btn-loading">
          <i class="fa fa-key"></i>
          <span>Semua Pengaturan</span>
        </a>
      </li>


      <li class="">
        <a href="index.php?page=ganti_password" class="btn-loading">
          <i class="fa fa-key"></i>
          <span>Ganti Password</span>
        </a>
      </li>



    </ul>


  </li>


</ul>