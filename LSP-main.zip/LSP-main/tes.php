ini post <br>

<?php
var_dump($_POST); ?>

<br> <br>

<br>
ini tes lagi 

<br> <br>



ini files <br>

<?php

var_dump($_FILES);


?>

<br> <br>

ini session <br>
<?php
session_start();

var_dump($_SESSION);

?>